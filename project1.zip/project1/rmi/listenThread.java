package rmi;

import java.io.*;
import java.net.*;
import java.lang.reflect.*;

public class listenThread<T> extends Thread{

	private Skeleton<?> skeleton=null;
	private Class<T> sClass=null;
	private ServerSocket listen_socket=null;
	private Exception exception=null;

	public listenThread(Skeleton<?> sk, Class<T> c, ServerSocket ls){
		this.skeleton = sk;
		this.sClass = c;
		this.listen_socket = ls;
	} 


	@Override
	public void run(){
		while(this.skeleton.isRunning() && !this.isInterrupted()){
			try{
				Socket client=this.listen_socket.accept();
				processThread process_thread=new processThread(this.skeleton, this.sClass, client);
				if (this.skeleton.isRunning())
					process_thread.start();
			}
			catch(IOException e){	//Why IOException
				if (!this.skeleton.isRunning() || !this.skeleton.listen_error(e)){
					this.skeleton.stopRunning();
					this.interrupt();
					this.exception=e;
				}
			}			
		}
		this.skeleton.stopped(this.exception);
	}


}