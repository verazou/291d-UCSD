package rmi;

import java.io.*;

public class RMIObject implements Serializable{
	private static final long serialVersionUID = 1L;
	private Object object = null;
	private boolean hasException = false;

	public RMIObject(Object o, boolean e){
		this.object = o;
		this.hasException = e;
	}

	public Object getObject(){
		return this.object;
	}

	public boolean hasException(){
		return this.hasException;
	}
}