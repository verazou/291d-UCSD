package rmi;

import java.lang.reflect.*;
import java.net.*;
import java.io.*;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class StubInvocationHandler implements InvocationHandler{
	private String hostName;
	private int port;
	private Class remoteInterface;

	public StubInvocationHandler(String hostName, int port, Class c){
		this.hostName = hostName;
		this.port = port;
		this.remoteInterface = c;
	}

	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable{
		
		if (method.getName() == "toString" && method.getParameterTypes().length == 0){
			return "Remote Interface: " + this.remoteInterface.getName() + "\n" 
			+ "Remote Address: " + this.hostName + ": " + port + "\n";
		}

		if (method.getName() == "equals" && method.getReturnType().getName() == "boolean" 
			&& method.getParameterTypes().length == 1 && method.getParameterTypes()[0].getName() == "java.lang.Object"){
			if (args.length != 1 || args[0] == null)
				return false;

			if (!Proxy.isProxyClass(args[0].getClass()))
				return false;

			InvocationHandler handler = Proxy.getInvocationHandler(args[0]);

			if (handler.getClass() != this.getClass())
				return false;

			StubInvocationHandler sHandler = (StubInvocationHandler) handler;

			return this.hostName.equals(sHandler.getHostName()) && this.port == sHandler.getPort()
			&& this.remoteInterface.equals(sHandler.getRemoteInterface());
		}

		if (method.getName() == "hashCode" && method.getReturnType().getName() == "int" 
			&& method.getParameterTypes().length == 0){
			return this.remoteInterface.hashCode() * 13 + this.hostName.hashCode() * 7 + this.port * 3;
		}




		RMIObject result = null;

		try{
			Socket client = new Socket(hostName, port);
			ObjectOutputStream os = new ObjectOutputStream(client.getOutputStream());
			ObjectInputStream is = new ObjectInputStream(client.getInputStream());
			os.writeObject(method.getName());
			os.writeObject(method.getParameterTypes());
			os.writeObject(args);

			result = (RMIObject) is.readObject();
			client.close();
		}catch(Exception e){
			throw new RMIException(e.getCause());
		}
		
		if (result.hasException()){
			throw new RMIException((Throwable) result.getObject());
		}

		return result.getObject();
	}

	public String getHostName(){
		return this.hostName;
	}

	public int getPort(){
		return this.port;
	}

	public Class getRemoteInterface(){
		return this.remoteInterface;
	}


}

