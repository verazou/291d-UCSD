package rmi;

import java.io.*;
import java.net.*;
import java.lang.reflect.Proxy;
import java.lang.reflect.Method;

public class processThread<T> extends Thread{
	
	private Skeleton<?> skeleton=null;
	private Class<T> sClass=null;
	private Socket client=null;
	private Method sMethod=null;

	public processThread(Skeleton<?> sk, Class<T> c, Socket cli){
		this.skeleton = sk;
		this.sClass = c;
		this.client = cli;
	} 

	@Override
	public void run(){
		try{
			ObjectOutputStream os=new ObjectOutputStream(this.client.getOutputStream());
			os.flush();
			ObjectInputStream is=new ObjectInputStream(this.client.getInputStream());
			String methodName=(String) is.readObject();
			Class<?>[] parameterTypes=(Class []) is.readObject();
			Object[] args=(Object[]) is.readObject();

			RMIObject sObject = null;

			try{
				this.sMethod=this.sClass.getMethod(methodName, parameterTypes);
			}
			catch(Exception e){
				sObject = new RMIObject(new RMIException(e.getCause()), true);
			}

			if (this.sMethod != null){
				try{
					Object returnObject=this.sMethod.invoke(this.skeleton.getServer(), args);
					sObject=new RMIObject(returnObject, false);
				}
				catch(Exception e){
					sObject=new RMIObject(e.getCause(), true);
				}
			}

			os.writeObject(sObject);
			this.client.close();
		}catch(Throwable e){
			this.skeleton.service_error(new RMIException(e.getCause()));
		}

	}

}